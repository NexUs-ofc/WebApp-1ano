<%--
  Created by IntelliJ IDEA.
  User: 20260140-ieg
  Date: 28/09/2026
  Time: 12:35
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
  <head>
    <title>Administradores</title>

  </head>
  <body>
  
  </body>
</html>
