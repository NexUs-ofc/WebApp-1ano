<%--
  Created by IntelliJ IDEA.
  User: 20260140-ieg
  Date: 28/09/2026
  Time: 12:36
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib prefix="c" uri="jakarta.tags.core" %>
<html>
  <head>
    <title>Alimentos</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        margin: 40px;
      }
      table {
        width: 100%;
        border-collapse: collapse;
      }
      th, td {
        padding: 10px;
        border: 1px solid #cccccc;
      }
      th {
        background-color: #eeeeee;
      }
    </style>
  </head>
  <body>
  <h1>Lista de alimentos</h1>
  <c:if test="${empty alimentos}">
    <p>Nenhum alimento cadastrado</p>
  </c:if>
  <c:if test="${not empty alimentos}">
    <table>
      <thead>
      <tr>
        <th>ID</th>
        <th>Cód. de Barras</th>
        <th>Nome</th>
        <th>Marca</th>
        <th>Id categoria</th>
      </tr>
      </thead>
      <tbody>
      <c:forEach var="alimento" items="${alimentos}">
        <tr>
          <td><c:out value="${alimento.id}"/></td>
          <td><c:out value="${alimento.codigoBarras}"/></td>
          <td><c:out value="${alimento.nome}"/></td>
          <td><c:out value="${alimento.marca}"/></td>
          <td><c:out value="${alimento.idCategoria}"/></td>
        </tr>
      </c:forEach>
      </tbody>
    </table>
  </c:if>

  </body>
</html>
