package org.example.interdisciplinar.conexao;

import io.github.cdimascio.dotenv.Dotenv;
import java.sql.*;

public class Conexao {

        private static Dotenv dotenv = Dotenv.configure()
                .ignoreIfMissing()
                .load();


        public Connection getConnection () {
            try {


                Class.forName("org.postgresql.Driver");
                String url = dotenv.get("DB_URL", System.getenv("DB_URL"));
                String user = dotenv.get("DB_USER", System.getenv("DB_USER"));
                String password = dotenv.get("DB_PASSWORD", System.getenv("DB_PASSWORD"));
                System.out.println("URL carregada: " + (url != null));
                System.out.println("Usuário carregado: " + (user != null));
                System.out.println("Senha carregada: " + (password != null));
                System.out.println("Tamanho da senha: " + (password != null ? password.length() : 0));
                System.out.println("Usuário: [" + user + "]");

                return DriverManager.getConnection(url, user, password);

            } catch (SQLException sqle) {
                sqle.printStackTrace();
                System.out.println("Erro ao se conectar sql");
                return null;

            } catch (ClassNotFoundException cnfe) {
                cnfe.printStackTrace();
                System.out.println("Erro ao se conectar cnf");
                return null;
            }
        }

        // Método para fechar a conexão

        public void closeConnection(Connection conn){
            if(conn != null) {
                try {
                    conn.close();
                } catch (SQLException sqle){
                    sqle.printStackTrace();
                }
            }
        }

}